// 20170928 新界面js write by Steven
